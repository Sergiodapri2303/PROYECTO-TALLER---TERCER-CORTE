Proyecto: Damas Internacionales - Versión básica y modular
Autor: Sergio Prieto

Lenguaje: C++
Descripción:
Versión simple del juego de Damas Internacionales en consola.
Implementa un tablero 10x10, piezas, movimiento, captura y coronación.
No usa conceptos avanzados, solo lo necesario para cumplir con los requisitos del parcial.

Estructura del proyecto:
- Pieza.h / Pieza.cpp
- Tablero.h / Tablero.cpp
- Juego.h / Juego.cpp
- main.cpp

Cómo compilar:
g++ main.cpp Juego.cpp Tablero.cpp Pieza.cpp -o damas -std=c++17

Uso:
- Al iniciar se muestra el tablero 10x10.
- Cada jugador (w / b) tiene 20 piezas.
- Ingrese movimientos en formato: r1 c1 r2 c2 (filas y columnas 1..10)
- Es obligatorio capturar cuando se pueda.
- Cuando una pieza llega al otro extremo, se convierte en dama (W o B).
- Para salir ingrese 0.
