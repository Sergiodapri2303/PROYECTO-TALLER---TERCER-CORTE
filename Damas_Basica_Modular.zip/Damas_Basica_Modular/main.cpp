#include "Juego.h"

int main() {
    Juego partida;
    partida.iniciar();
    return 0;
}
